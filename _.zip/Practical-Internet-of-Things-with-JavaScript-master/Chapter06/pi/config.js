module.exports = {
    mqtt: {
        host: '10.2.195.14',
        clientId: 'rPI_3',
        port: 8883
    }
};
